//filename: testTbag.cxx
//Author: Kyle Bui
//Date: 11/18/2022

#include <iostream>
#include <cstdlib>
#include "tbag.h" 
using namespace std;
using namespace kyle_bui;

int main()
{
	tbag <int> b1;
	tbag <int> b2;
	tbag <int> b3;
	
	b1.insert(2);
	b1.insert(3);
	b1.insert(1);
	b1.insert(1);
	b1.insert(1);
	
	b2.insert(8);
	b2.insert(7);
	b2.insert(9);
	b2.insert(9);
	b2.insert(9);
	
	
	cout << "Number of copies of target removed is " << b1.erase(1) << endl;
	cout << "Number of 1's in the bag: " << b1.count(1) << endl;
	cout << "Number of 2's in teh bag: " << b1.count(2) << endl;
	
	int outcome;
	outcome = b1.erase_one(4);
	
	if (outcome == 1)
	{
	  cout << "Target removed" << endl;
	}
	else
	  cout << "Target was not found" << endl;
	
	cout << "Size of bag 1 before: " << b1.size() << endl;
	b1+=b2;
	cout << "Size of bag 1 after: " << b1.size() << endl;
	cout << "Size of bag 3 before: " << b3.size() << endl;
	b3=b1;
	cout << "Size of bag 3 after: " << b3.size() << endl;
	
	cout << "I will choose a random number from the bag: " << b1.grab() << endl;
		
	return EXIT_SUCCESS;
}

